class FPNode:
    def __init__(self, item, count):
        self.item = item
        self.count = count
        self.children = {}
        self.parent = None

def create_fp_tree(transactions, min_support):
    # Count item frequencies in the transactions
    item_counts = {}
    for transaction in transactions:
        for item in transaction:
            item_counts[item] = item_counts.get(item, 0) + 1

    # Remove infrequent items from the item counts
    item_counts = {item: count for item, count in item_counts.items() if count >= min_support}

    # Sort items based on frequency
    frequent_items = sorted(item_counts.keys(), key=lambda item: item_counts[item], reverse=True)

    # Create the root of the FP-tree
    root = FPNode(None, 0)

    # Construct the FP-tree
    for transaction in transactions:
        transaction = [item for item in transaction if item in item_counts]
        transaction.sort(key=lambda item: item_counts[item], reverse=True)
        insert_transaction(root, transaction)

    return root, item_counts

def insert_transaction(node, transaction):
    if not transaction:
        return

    item = transaction[0]
    if item in node.children:
        child_node = node.children[item]
    else:
        child_node = FPNode(item, 0)
        child_node.parent = node
        node.children[item] = child_node

    child_node.count += 1
    insert_transaction(child_node, transaction[1:])

def find_frequent_itemsets(root, item_counts, min_support):
    frequent_itemsets = []

    def find_frequent_itemsets_helper(node, current_itemset):
        for item, child_node in node.children.items():
            new_itemset = current_itemset.copy()
            new_itemset.append(item)

            support = item_counts[item]
            if support >= min_support:
                frequent_itemsets.append((new_itemset, support))

            find_frequent_itemsets_helper(child_node, new_itemset)

    find_frequent_itemsets_helper(root, [])

    return frequent_itemsets

# Example usage
transactions = [
    ["cheese", "lassi", "butter","yougurt","tea powder","sugar","egg","candy"],
    ["lassi","coffee powder","butter","cheese","sweet","egg","flour"],
    ["coffee powder","cheese","panner","bread","flour"],
    ["coffee powder","butter","milk","popcorn","candy"],
    ["lassi","cheese","butter","ghee","sweet","candy","egg","pasta"],
]

min_support = 3

fp_tree, item_counts = create_fp_tree(transactions, min_support)
frequent_itemsets = find_frequent_itemsets(fp_tree, item_counts, min_support)
print(frequent_itemsets)

sorted_itemsets = sorted(frequent_itemsets, key=lambda x: (len(x[0]), -x[1]))

# Print the sorted frequent itemsets line by line
for itemset, support in sorted_itemsets:
    print(itemset, support)

