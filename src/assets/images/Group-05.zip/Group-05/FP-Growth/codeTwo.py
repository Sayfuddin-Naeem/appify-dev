from mlxtend.preprocessing import TransactionEncoder
#TransactionEncoder is used for one-hot encoding the transaction
from mlxtend.frequent_patterns import fpgrowth
#fpgrowth is the FP-growth algorithm implementation provided by the mlxtend library
import pandas as pd
#pandas library is used for handling data in DataFrames

# Example transaction dataset
data = {
    'Transaction_ID': [1, 2, 3, 4, 5],
    'Items': [['cheese', 'lassi', 'butter', 'yougurt', 'tea powder', 'sugar', 'egg', 'candy'],
              ['lassi', 'coffee powder', 'butter', 'cheese', 'sweet', 'egg', 'flour'],
              ['coffee powder', 'cheese', 'panner', 'bread', 'flour'],
              ['coffee powder', 'butter', 'milk', 'popcorn', 'candy'],
              ['lassi', 'cheese', 'butter', 'ghee', 'sweet', 'candy', 'egg', 'pasta']]
}

# Convert data to a DataFrame
df = pd.DataFrame(data)

# One-hot encode the transactions with boolean values
#One-hot encoding converts the list of items into a binary representation
te = TransactionEncoder()
one_hot_encoded = te.fit(df['Items']).transform(df['Items'])
df_encoded = pd.DataFrame(one_hot_encoded, columns=te.columns_)

# Apply the FP-growth algorithm with minimum support set to 40% transactions
frequent_itemsets = fpgrowth(df_encoded, min_support=.4, use_colnames=True)

# Display the frequent itemsets
print(frequent_itemsets)
